<?php	
  $arr = [
    [
        "name" => "Mario",
        "surname" => "Verdi"
    ],
    [
        "name" => "Giovanni",
        "surname" => "Rossi"
    ],
    [
        "name" => "Giuseppe",
        "surname" => "Bianchi"
    ]
];
   echo json_encode($arr);
?>
 