<?php

	$data = json_decode(stripslashes($_POST['arraydata']));

   print_r($data);
 
  
?>